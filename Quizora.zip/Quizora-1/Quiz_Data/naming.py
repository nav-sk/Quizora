sno = (0, 1, 2, 3, 4)

question = ('Who is known as "The Saint of Gutters" ?',
            'Who is known as the "Father of Lok Sabha"? ',
            'Who is known as "Little Corporal"?',
            'Who has become the first Indian woman to scale Mt.Everest for the 4th time?',
            'Mrs.Mara Sahib Fathima Beevi is distinguished as the first lady_____ .')
opt1 = ('B.R.Ambedkar ', 'Anantasayanam', 'Afolf Hitler', 'Anush Jamsenpa', 'Judge of The High Court')
opt2 = ('Mother Teresa', 'Bashyam', 'Napolean Bonaparte', 'Dickey Dolmer ', 'Governor of a State')
opt3 = ('Mahatma Ghandhi', 'Mavlankan', 'William Goldstone', 'Lhakpa Sherpa', 'Judge of the Supreme Court')
opt4 = ('Baba Amte', 'Zakir Hussain', 'Alexander the greate', 'Malavath Purna', 'Gold medal winner')

correct_ans = ('Mother Teresa', 'Mavlankan', 'Napolean Bonaparte', 'Anush Jamsenpa', 'Judge of the Supreme Court')

options = (opt1, opt2, opt3, opt4)
