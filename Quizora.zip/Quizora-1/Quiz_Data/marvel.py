sno = (0, 1, 2, 3, 4)

question = ('The name of famous Marvel Character whose cast is recently died of cancer is ',
            'The character who was addressed as \'God of Mischief\' in MCU is',
            'The film which had highest Box Office Collection is',
            'The place where the Soul Stone in MCU is ',
            'The fictional place "Wakanda" is located in the continent ')

opt1 = ('Black Panther', 'Thor', 'Avatar', 'Earth', 'Asia')
opt2 = ('Black Widow', 'Odin', 'Avengers: EndGame', 'Morag', 'Africa')
opt3 = ('Ant Man', 'Loki', 'Avengers: Infinity War', 'Knowhere', 'Antarctica')
opt4 = ('Captain America', 'Hela', 'Titanic', 'Volmir', 'Australia')

correct_ans = ('Black Panther', 'Loki', 'Avengers: EndGame', 'Volmir', 'Africa')

options = (opt1, opt2, opt3, opt4)