sno = (0, 1, 2, 3, 4)

question = ("'OS' Computer abbreviation.",
            " '.MOV' extension refers usually to what kind of file",
            'Which is a type of Electrically Erasable Programmable  Read Only Memory?',
            'Who developed Yahoo?',
            "In which year was the' @' choosen for the use in e-mails addressess?")

opt1 = ('Order of Significance', 'Image file', 'flash', 'Dennis Ritchie', '1976')
opt2 = ('Open Software', 'Animation or movie file', 'flange', 'David Flio and Jerry Yang', '1972')
opt3 = ('Operating System', 'Audio file', 'fury', 'Vint Cerf', '1980')
opt4 = ('Optical Sensor', 'MS Office dovument', 'FRAM', 'Steve Case', '1984')

correct_ans = ('Operating System', 'Animation or movie file', 'flash', 'David Flio and Jerry Yang', '1972')

options = (opt1, opt2, opt3, opt4)
