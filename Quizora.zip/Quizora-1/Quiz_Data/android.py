sno=( 0, 1, 2, 3, 4)
question=('Android was officially released in ',
          'Initially android was created as a operating system for ',
          'The name of android version 4.4 is ',
          'The latest android version released is',
          'The android version used by NASA ')

opt1=( '2007','Digital clocks','Froyo','Pie','Kitkat')
opt2=('2008','Music players','Lollipop','Oreo','Honey comb')
opt3=('2010','Mobile Phones','KitKat','Android 11','Fryo')
opt4=('2006 ','Digital Cameras','Oreo','Android 10 ','Gingerbread')

correct_ans=('2008','Digital Cameras','KitKat','Android 11','Gingerbread')

options = (opt1, opt2, opt3, opt4)
