sno = (0, 1, 2, 3, 4)

question = ('The highest rainfall in the world is recorded the the state of ',
            'In India, A dedicated temple for rats is located in ',
            'The national beverage of India is ',
            'The tallest statue in the world is named as',
            'Science Day in Switzerland was declared on the honor of an Indian Scientist ')

opt1 = ('Meghalaya', 'Maharashtra', 'Coffee', 'Statue of Liberty', 'Dr. A.P.J Abdul Kalam')
opt2 = ('Himachal Pradesh', 'Karnataka', 'Tea', 'Christ the Redeemer', 'Sir CV Raman')
opt3 = ('Kerala', 'Rajasthan', 'Flavoured Milk', 'Leshan Giant Buddha', 'Vikram Ambalal Sarabhai')
opt4 = ('Nagaland', 'Tamil Nadu', 'Wine', 'Statue of Unity', 'Jagadish Chandra Bose')

correct_ans = ('Meghalaya', 'Rajasthan', 'Tea', 'Statue of Unity', 'Dr. A.P.J Abdul Kalam')

options = (opt1, opt2, opt3, opt4)