sno = (0, 1, 2, 3, 4)

question = ('What was the first commercially successful video game?',
            'What is the best selling videogame of all time?',
            'The US Air Force used what gaming console to create a cluster supercomputer?',
            'What food was the character Pac Man modeled after ?',
            'what is the most expensive video game made to date ?')
opt1 = ('Pong', 'Angry bird', 'XBox', 'Pizza', 'COD:Modern Warefare 2')
opt2 = ('Tic tac', 'Minecraft', 'Playstation', 'Cookies', 'GTA Five')
opt3 = ('Pac Man', 'Pac Man', 'XBox2', 'Pan cake', 'PUBG')
opt4 = ('Snake game ', 'Tekken series', 'PS 3', 'Pie', 'Mortal Kombat ')

correct_ans = ('Pong', 'Minecraft', 'PS 3', 'Pizza', 'GTA Five')

options = (opt1, opt2, opt3, opt4)
