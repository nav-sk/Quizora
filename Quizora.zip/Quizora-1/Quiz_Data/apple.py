sno = (0, 1, 2, 3, 4)
question = ('The first Apple logo was featured by  ',
            'The name of the latest Apple\'s own chipset for PC\'s has the architecture ',
            'The first iPhone was introduced in the year',
            'The maximum camera resolution in iPhones and iPad till date is',
            'Every third person employing Apple is from ')

opt1 = ('Steve Jobs', 'x86', '2007', '64MP', 'India')
opt2 = ('Tim Cook', 'ARM-based', '2006', '108MP', 'U.S.A')
opt3 = ('Wojeniac', 'x64', '2010', '12MP', 'U.K')
opt4 = ('Sir Isaac Newton', 'PowerPC', '2005', '20MP', 'China')

correct_ans = ('Sir Isaac Newton', 'ARM-based', '2007', '12MP', 'India')

options = (opt1, opt2, opt3, opt4)
