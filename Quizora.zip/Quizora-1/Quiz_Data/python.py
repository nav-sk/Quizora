sno = (0, 1, 2, 3, 4)
question = ('Python is a language of type ',
            'Python was a project which was done ',
            'The developer named Python after ',
            'The inbuilt poem in Python written by Tim Peter can be viewed by importing ',
            'Python Programming cannot be applied to ')

opt1 = ('General Purpose Language', 'in company', "The developer's pet ", 'this', 'Web Development')
opt2 = ('Scripting Language', 'in college', "Monty Python's Flying Circus TV Show", 'poem', 'Machine Learning')
opt3 = ('Markup Language', 'in school', 'a cartoon character ', 'zen', 'low-level systems')
opt4 = ('Assembly Language', 'as hobby', 'Python Snake ', 'that', 'Computer Graphics')

correct_ans = ('Scripting Language', 'as hobby', "Monty Python's Flying Circus TV Show", 'this', 'low-level systems')

options = (opt1, opt2, opt3, opt4)
