sno = (0, 1, 2, 3, 4)

question = ('Which of the following is a greenhouse gas?',
            'Which of these countries emits the most carbon dioxide?',
            'Which day is Earth Day?',
            "Where does the majority of plastic waste end up",
            "How much of the Earth’s land is covered by forests?")

opt1 = ('CO2', 'China', 'August 12', 'Burned for Energy', '5%')
opt2 = ('CH4', 'U.S.A', 'October 31', 'Oceans', '10%')
opt3 = ('Water Vapour', 'India', 'December 21', 'Landfills', '16%')
opt4 = ('All the Above', 'Russia', 'April 22', 'Recycled', '31%')

correct_ans = ('All the Above', 'China', 'April 22', 'Oceans', '31%')

options = (opt1, opt2, opt3, opt4)
