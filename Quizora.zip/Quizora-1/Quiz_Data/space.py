sno = (0, 1, 2, 3, 4)

question = ('Which is the smallest planet on the solar system?',
            'Which is the second smallest planet in the solar system?',
            'The moon called Titan orbits which planet?',
            "Which is the brightest planet in the night's sky",
            'Uranus has only been visited by what spacecraft?')
opt1 = ('Venus', 'Mars', 'Plato', 'Earth', 'Sputnik')
opt2 = ('Mercury', 'Earth', 'Saturn', 'Venus', 'The voyager 2',)
opt3 = ('Pluto', 'Venus', 'Jupiter', 'Saturn', 'The roover')
opt4 = ('Mars', 'none of the above', 'Uranus', 'Dwarf planet', 'The voyager')

correct_ans = ('Mercury', 'Mars', 'Saturn', 'Venus', 'The voyager 2')

options = (opt1, opt2, opt3, opt4)
