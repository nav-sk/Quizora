# WhiteHat StormBreakers
# National Matric Hr Sec School, Mettupalayam


This applicatíon needs the following:

1) python3.9
2) kivy==2.0.0   # install by executing "py -m pip install kivy"
3) kivymd==0.104.2.dev   #install by executing "py -m pip install https://github.com/kivymd/KivyMD/archive/master.zip"
4) If your OpenGL version is <2.0, try upgrading your graphics driver to the latest.


### Run the application by running the main.py file.